import mee

for i in range(4):
    m ee.moveAgent("up")
    for j in range(4):
        for k in range(3):
            mee.placeBlock(1, "down")
            mee.moveAgent("forward")

        mee.turnAgent("left")
